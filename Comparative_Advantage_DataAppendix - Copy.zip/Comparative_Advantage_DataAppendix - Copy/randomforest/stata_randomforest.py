  import sys
%load_ext autoreload
%autoreload 2
import ipdb
import statsmodels.discrete.discrete_model as sm
import matplotlib.pyplot as plt
import pandas as pd



# Load Stata File
statafile = sys.argv[1]
data = pd.read_stata(statafile)

#setup X and y
y = data[0]
X = data[1:]


### Logit
m = sm.Logit(y, X).fit()
m.summary()
p_logit = m.predict(X)

###

###Random Forest Classifier
from sklearn.ensemble import RandomForestClassifier
clt = RandomForestClassifier(min_samples_split=20, random_state=99)
clt = clt.fit(X,y)
p = clt.predict_proba(X_test)


### Create Plot Object
fig , axes = plt.subplots(nrows=2, ncols=2)


### Figure A: Binned for Random Forest
preds = pd.DataFrame(dict(pred=p[:,1], y=y_test))        
#Create a binned out of sample distribution graph a la Guzman and Stern (2015)
preds = preds.sort_values('pred')
preds = preds.reset_index()
num_bins = 20
preds['percentile'] = np.floor(preds.index.values * num_bins / preds.pred.count())/num_bins
plot_bins  = preds.groupby("percentile")['y'].sum() / preds.y.sum()
a = plot_bins.plot(kind = 'bar', title="Binned Performance of Algorithm Random Forest", ax=axes[0,0])
a.set_ylabel("Share of all conversions")
a.set_xlabel("")



### Figure B: Distribution of P(Conversion)
plot_means  = preds.groupby("percentile")['y'].mean()
a= plot_means.plot(kind="bar", title="Mean P(Conversion) Random Forest" , ax=axes[0,1])
a.set_xlabel("")


### Figure C: Distribution in top 10%
num_bins = 400
preds['percentile'] = np.floor(preds.index.values * num_bins / preds.pred.count())/num_bins
plot_top  = preds.loc[preds.percentile >= .9,:].groupby("percentile")['y'].mean()
plot_top.plot(kind="bar",title="Mean P(Conversion) Random Forest", ax=axes[1,0])



### Figure D: Binned for Logit
preds = pd.DataFrame(dict(pred=plogit, y=y_test))        
#Create a binned out of sample distribution graph a la Guzman and Stern (2015)
preds = preds.sort_values('pred')
preds = preds.reset_index()
num_bins = 20
preds['percentile'] = np.floor(preds.index.values * num_bins / preds.pred.count())/num_bins
plot_bins  = preds.groupby("percentile")['y'].sum() / preds.y.sum()
a = plot_bins.plot(kind = 'bar', title="Binned Performance of Algorithm Logit", ax=axes[1,1])
a.set_ylabel("Share of all conversions")
a.set_xlabel("Percentile of P(conversion)")


plt.show()

### End of model by hand


