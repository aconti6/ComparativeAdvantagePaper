
*********************************************************************************************************************************
*								The Hidden Costs of Fairness in Platform Markets: The Dynamics of Lowering Developer Royalty Rates
*********************************************************************************************************************************
											*********************************************
											*			Thus version: September 2025	*
											*		     annamaria.conti@ie.edu         *
											*			   juan.santalo@ie.edu		    *
											*********************************************
clear all
set maxvar 120000
	
**Here we set the globals
	global shared_folder "D:\Project_Hunt_Anna_Juan\Analysis\DO\Replication_Package"
	global intermediary_directory "${shared_folder}\intermediary_datasets"
    global final_directory "${shared_folder}\final_datasets_for_regressions_figures"
    global figures "${shared_folder}\figures"

**********************************************************************
****The scope here is to henerate a panel at the hunter-platform lvel
**********************************************************************

*We begin by generating a panel for hunters, hunting apps on iOS
*Then, we generate a panel for hunters, hunting apps on Android
*The hunting behavior of each hunter in a given platform is observed for 25 months: the 12 months before the royalty rate cut announcement, the month of the announcement itself, and the 12 months following it
*Finally, we merge the two panels

****************************************************
****We start from processing apps launched on ios and their hunters
****************************************************
*We start from the dataset of product launches
use "$intermediary_directory\dataset_ready_hunter.dta", replace

gen year=year(date)
gen month=month(date)
gen edate = ym(year, month) 
format edate %tm
drop year month



*If upvotes are missing, we replace the missing values with 1 because the makers always give an upvote to their app
replace upvotes="1" if upvotes=="N/A"
destring upvotes, replace

replace Users_rated="" if Users_rated=="N/A"
destring Users_rated, replace

replace Rating="" if Rating=="N/A"
destring Rating, replace

replace comments="" if comments=="N/A"
destring comments, replace


*Here, we determine the platforms where the apps were lounched: iOS, Web, Android

gen ios=strpos(Platforms, "iOS")>0 
gen android=strpos(Platforms, "Android")>0 

gen web=strpos(Platforms, "Web")>0
replace web=0 if ios==1
replace web=0 if android==1

*We only keep apps launched on iOS 
drop if web==1
keep if ios==1

**We determine the quality of iOS apps
foreach num of numlist 25 50 90 75 95 {
by edate, sort: egen pct_upvotes_`num'=pctile(upvotes), p(`num')
by edate, sort: egen pct_Rating_`num'=pctile(Rating), p(`num')

        }
		
foreach num of numlist 50 90  95 {
gen upvotes_`num'=upvotes>=pct_upvotes_`num'
gen Rating_`num'=Rating>=pct_Rating_`num'

        }
		
foreach num of numlist 75 {
gen upvotes_`num'=upvotes>=pct_upvotes_`num'
gen Rating_`num'=Rating>=pct_Rating_`num'

        }
		
foreach num of numlist 25 {
gen upvotes_`num'=upvotes<=pct_upvotes_`num'
gen Rating_`num'=Rating<=pct_Rating_`num'

        }

		
foreach num of numlist 25 50 90 75 {
replace Rating_`num'=. if Rating==.


        }
		

drop pct_upvotes_25 pct_upvotes_50 pct_upvotes_95 pct_Rating_50  pct_Rating_25 pct_upvotes_90 pct_Rating_90 pct_upvotes_75 pct_Rating_75 


**We attach data from Crunchbase, determining which apps become startups/funded startups
merge m:1 id using "$intermediary_directory\data_crunchbase.dta",  keep(1 3) nogen

gen launched_ios_startup=company_uuid!="" & (founding_edate>tm(2019m5) ) & (ios==1)
gen launched_ios_startupf=total_funding!=. & (ios==1)

gen launched_android_startup=company_uuid!="" & (founding_edate>tm(2019m5) ) & (android==1)
gen launched_android_startupf=total_funding!=. & (android==1)

gen launched_iosandroid_startup=company_uuid!="" & (founding_edate>tm(2019m5) ) & (android==1 | ios==1)
gen launched_iosandroid_startupf=total_funding!=. & (android==1 | ios==1)



***************************************************************************************************************************************************************************************
*We work on the hunters: We need to identify the external hunters. External hunters are people who are different from the makers. The makers are listed in the variable "Made_By"
***************************************************************************************************************************************************************************************

**Here we clean the strings Hunted_By and Made_By
order Hunted_By Made_By
replace Made_By="" if Made_By=="N/A"
replace Made_By = subinstr(Made_By, ".", "",.)
replace Made_By = subinstr(Made_By, " and ", ", ",.) 
replace Made_By=lower(Made_By)
replace Made_By=trim(Made_By)
replace Hunted_By=lower(Hunted_By)
replace Hunted_By=trim(Hunted_By)



***We keep the Made_by info for later merge
preserve
keep id Made_By
duplicates drop id, force
save "$intermediary_directory\made_by.dta", replace
restore




*We determine the internal hunters (that is, the makers of an app) and drop apps with no hunter associated

split Made_By, parse(,) generate(Made_By_n)

foreach num of numlist 1(1)56 {
replace Made_By_n`num'=trim(Made_By_n`num')
        }

*Internal hunters are makers hunting their own app
gen internal_hunter=Hunted_By==Made_By_n1  | Hunted_By==Made_By_n2 | Hunted_By==Made_By_n3 | Hunted_By==Made_By_n4 | Hunted_By==Made_By_n5 | Hunted_By==Made_By_n6 | Hunted_By==Made_By_n7 | Hunted_By==Made_By_n8 | Hunted_By==Made_By_n9 | Hunted_By==Made_By_n10 | Hunted_By==Made_By_n11 | Hunted_By==Made_By_n12 | Hunted_By==Made_By_n13 | Hunted_By==Made_By_n14 | Hunted_By==Made_By_n15 | Hunted_By==Made_By_n16 | Hunted_By==Made_By_n17 | Hunted_By==Made_By_n18 | Hunted_By==Made_By_n19 | Hunted_By==Made_By_n20 | Hunted_By==Made_By_n21 | Hunted_By==Made_By_n22 | Hunted_By==Made_By_n23 | Hunted_By==Made_By_n24 | Hunted_By==Made_By_n25 | Hunted_By==Made_By_n26 | Hunted_By==Made_By_n27 | Hunted_By==Made_By_n28 | Hunted_By==Made_By_n29 | Hunted_By==Made_By_n30 | Hunted_By==Made_By_n31 | Hunted_By==Made_By_n32 | Hunted_By==Made_By_n33 | Hunted_By==Made_By_n34 | Hunted_By==Made_By_n35 | Hunted_By==Made_By_n36 | Hunted_By==Made_By_n37 | Hunted_By==Made_By_n38 | Hunted_By==Made_By_n39 | Hunted_By==Made_By_n40 | Hunted_By==Made_By_n41 | Hunted_By==Made_By_n42 | Hunted_By==Made_By_n43 | Hunted_By==Made_By_n44 | Hunted_By==Made_By_n45 | Hunted_By==Made_By_n46 | Hunted_By==Made_By_n47 | Hunted_By==Made_By_n48 | Hunted_By==Made_By_n49 | Hunted_By==Made_By_n50 | Hunted_By==Made_By_n51 | Hunted_By==Made_By_n52 | Hunted_By==Made_By_n53 | Hunted_By==Made_By_n54 | Hunted_By==Made_By_n55 | Hunted_By==Made_By_n56 | Hunted_By==Made_By_n57

order Hunted_By Made_By internal_hunter
		
drop Made_By_n*

gen no_Made_By=Made_By==""



*We keep hunter info for later merge
preserve
keep id Hunted_By
duplicates drop id, force
save "$intermediary_directory\hunted_by.dta", replace
restore


******************************************************************************************
***We generate a dataset at the hunter-ios level, only keeping the external hunters
******************************************************************************************

**Here we exclude the internal hunters from the set of hunters
keep if internal_hunter==0
drop if Hunted_By=="."
drop if Hunted_By=="a"

**We clean up the names of the external hunters
clean_name Hunted_By, case(proper)
stnd_compname Hunted_By, gen(stn_name stn_dbaname stn_fkaname entitytype attn_name)
drop stn_dbaname stn_fkaname attn_name
rename stn_name Hunted_Byy
drop entitytype
drop Hunted_By
rename Hunted_Byy Hunted_By

**We generate a numerical identifier for the external hunters
egen hunter_id=group(Hunted_By)


**We assess whether hunters hunted successful apps 
gen ios_or_android=ios==1 | android==1 
gen ios_up90=ios==1 & upvotes_90==1
gen ios_rat75=ios==1 & Rating_75==1


**We sum the hunters' successful "hunts" by year-month
by hunter_id edate, sort: egen sum_product_hunted=sum(ios_or_android)
by hunter_id edate, sort: egen sum_product_hunted_upv90=sum(ios_up90)
by hunter_id edate, sort: egen sum_product_hunted_rat75=sum(ios_rat75)
by hunter_id edate, sort: egen sum_launched_startup=sum(launched_ios_startup)
by hunter_id edate, sort: egen sum_launched_startupf=sum(launched_ios_startupf)


**This is a dataset at the hunter-ios-date level
duplicates drop hunter_id edate, force
keep  Hunted_By hunter_id edate Hunted_By sum_product_hunted sum_product_hunted_upv90  sum_product_hunted_rat75 sum_launched_startup sum_launched_startupf
save "$intermediary_directory\panel_hunter_intermed_MS_ios.dta", replace

***This is a dataset containing data on hunter_name and hunter_id
use "$intermediary_directory\panel_hunter_intermed_MS_ios.dta", replace
duplicates drop hunter_id, force
keep hunter_id Hunted_By
save "$intermediary_directory\panel_hunter_intermed_MS2_ios.dta", replace





****************************************************
**Now we work on Android apps and their hunters
****************************************************

use "$intermediary_directory\dataset_ready_hunter.dta", replace


gen year=year(date)
gen month=month(date)
gen edate = ym(year, month) 
format edate %tm
drop year month

*If upvotes are missing, we replace the missing values with 1 because the makers always give an upvote to their app
replace upvotes="1" if upvotes=="N/A"
destring upvotes, replace

replace Users_rated="" if Users_rated=="N/A"
destring Users_rated, replace

replace Rating="" if Rating=="N/A"
destring Rating, replace

replace comments="" if comments=="N/A"
destring comments, replace


*Here, we determine the platforms where the apps were lounched: iOS, Web, Android
gen ios=strpos(Platforms, "iOS")>0 
gen android=strpos(Platforms, "Android")>0 

gen web=strpos(Platforms, "Web")>0
replace web=0 if ios==1
replace web=0 if android==1

*We only keep apps launched on Android 
keep if android==1

**We determine the quality of apps launched on Android
foreach num of numlist 25 50 90 75 95 {
by edate, sort: egen pct_upvotes_`num'=pctile(upvotes), p(`num')
by edate, sort: egen pct_Rating_`num'=pctile(Rating), p(`num')

        }
		
foreach num of numlist 50 90  95 {
gen upvotes_`num'=upvotes>=pct_upvotes_`num'
gen Rating_`num'=Rating>=pct_Rating_`num'

        }
		

				
foreach num of numlist 75 {
gen upvotes_`num'=upvotes>=pct_upvotes_`num'
gen Rating_`num'=Rating>=pct_Rating_`num'

        }
		
		
foreach num of numlist 25 {
gen upvotes_`num'=upvotes<=pct_upvotes_`num'
gen Rating_`num'=Rating<=pct_Rating_`num'

        }

		
foreach num of numlist 25 50 90 75 {
replace Rating_`num'=. if Rating==.


        }


drop pct_upvotes_50 pct_upvotes_95 pct_Rating_50  pct_upvotes_25  pct_Rating_25  pct_upvotes_90  pct_Rating_90  pct_upvotes_75  pct_Rating_75



**We attach data from Crunchbase, determining which apps become startups/funded startups
merge m:1 id using "$intermediary_directory\data_crunchbase.dta",  keep(1 3) nogen


gen launched_ios_startup=company_uuid!="" & (founding_edate>tm(2019m5) ) & (ios==1)
gen launched_ios_startupf=total_funding!=. & (ios==1)

gen launched_android_startup=company_uuid!="" & (founding_edate>tm(2019m5) ) & (android==1)
gen launched_android_startupf=total_funding!=. & (android==1)

gen launched_iosandroid_startup=company_uuid!="" & (founding_edate>tm(2019m5) ) & (android==1 | ios==1)
gen launched_iosandroid_startupf=total_funding!=. & (android==1 | ios==1)


***************************************************************************************************************************************************************************************
*We work on the hunters: We need to identify the external hunters. External hunters are people who are different from the makers. The makers are listed in the variable "Made_By"
***************************************************************************************************************************************************************************************

**Here we clean the strings Hunted_By and Made_By
order Hunted_By Made_By
replace Made_By="" if Made_By=="N/A"
replace Made_By = subinstr(Made_By, ".", "",.)
replace Made_By = subinstr(Made_By, " and ", ", ",.) 
replace Made_By=lower(Made_By)
replace Made_By=trim(Made_By)
replace Hunted_By=lower(Hunted_By)
replace Hunted_By=trim(Hunted_By)



***We keep the Made_by info for later merge
preserve
keep id Made_By
duplicates drop id, force
save "$intermediary_directory\made_by.dta", replace
restore




*We determine the internal hunters (that is, the makers of an app) and drop apps with no hunter associated
split Made_By, parse(,) generate(Made_By_n)

foreach num of numlist 1(1)56 {
replace Made_By_n`num'=trim(Made_By_n`num')
        }

*Internal hunters are makers hunting their own app
gen internal_hunter=Hunted_By==Made_By_n1  | Hunted_By==Made_By_n2 | Hunted_By==Made_By_n3 | Hunted_By==Made_By_n4 | Hunted_By==Made_By_n5 | Hunted_By==Made_By_n6 | Hunted_By==Made_By_n7 | Hunted_By==Made_By_n8 | Hunted_By==Made_By_n9 | Hunted_By==Made_By_n10 | Hunted_By==Made_By_n11 | Hunted_By==Made_By_n12 | Hunted_By==Made_By_n13 | Hunted_By==Made_By_n14 | Hunted_By==Made_By_n15 | Hunted_By==Made_By_n16 | Hunted_By==Made_By_n17 | Hunted_By==Made_By_n18 | Hunted_By==Made_By_n19 | Hunted_By==Made_By_n20 | Hunted_By==Made_By_n21 | Hunted_By==Made_By_n22 | Hunted_By==Made_By_n23 | Hunted_By==Made_By_n24 | Hunted_By==Made_By_n25 | Hunted_By==Made_By_n26 | Hunted_By==Made_By_n27 | Hunted_By==Made_By_n28 | Hunted_By==Made_By_n29 | Hunted_By==Made_By_n30 | Hunted_By==Made_By_n31 | Hunted_By==Made_By_n32 | Hunted_By==Made_By_n33 | Hunted_By==Made_By_n34 | Hunted_By==Made_By_n35 | Hunted_By==Made_By_n36 | Hunted_By==Made_By_n37 | Hunted_By==Made_By_n38 | Hunted_By==Made_By_n39 | Hunted_By==Made_By_n40 | Hunted_By==Made_By_n41 | Hunted_By==Made_By_n42 | Hunted_By==Made_By_n43 | Hunted_By==Made_By_n44 | Hunted_By==Made_By_n45 | Hunted_By==Made_By_n46 | Hunted_By==Made_By_n47 | Hunted_By==Made_By_n48 | Hunted_By==Made_By_n49 | Hunted_By==Made_By_n50 | Hunted_By==Made_By_n51 | Hunted_By==Made_By_n52 | Hunted_By==Made_By_n53 | Hunted_By==Made_By_n54 | Hunted_By==Made_By_n55 | Hunted_By==Made_By_n56 | Hunted_By==Made_By_n57


order Hunted_By Made_By internal_hunter
		
drop Made_By_n*

gen no_Made_By=Made_By==""


*We keep hunter info for later merge
preserve
keep id Hunted_By
duplicates drop id, force
save "$intermediary_directory\hunted_by.dta", replace
restore


******************************************************************************************
***We generate a dataset at the hunter-android level, only keeping the external hunters
******************************************************************************************

**We drop the internal hunters
keep if internal_hunter==0
drop if Hunted_By=="."
drop if Hunted_By=="a"


**We clean up the names of the external hunters
clean_name Hunted_By, case(proper)
stnd_compname Hunted_By, gen(stn_name stn_dbaname stn_fkaname entitytype attn_name)
drop stn_dbaname stn_fkaname attn_name
rename stn_name Hunted_Byy
drop entitytype
drop Hunted_By
rename Hunted_Byy Hunted_By

**We generate a numerical identifier for the external hunters
egen hunter_id=group(Hunted_By)


**We assess whether hunters hunted successful apps 
gen ios_or_android=ios==1 | android==1
gen android_up90=android==1 & upvotes_90==1
gen android_rat75=android==1 & Rating_75==1



**We sum the hunters' successful "hunts" by year-month
by hunter_id edate, sort: egen sum_product_hunted=sum(ios_or_android)
by hunter_id edate, sort: egen sum_product_hunted_upv90=sum(android_up90)
by hunter_id edate, sort: egen sum_product_hunted_rat75=sum(android_rat75)
by hunter_id edate, sort: egen sum_launched_startup=sum(launched_android_startup)
by hunter_id edate, sort: egen sum_launched_startupf=sum(launched_android_startupf)


**This is a dataset at the hunter-android-date level
duplicates drop hunter_id edate, force
keep  Hunted_By hunter_id edate Hunted_By sum_product_hunted sum_product_hunted_upv90  sum_product_hunted_rat75 sum_launched_startup sum_launched_startupf  
save "$intermediary_directory\panel_hunter_intermed_MS_android.dta", replace

***This is a dataset containing data on hunter_name and hunter_id
use "$intermediary_directory\panel_hunter_intermed_MS_android.dta", replace
duplicates drop hunter_id, force
keep hunter_id Hunted_By
save "$intermediary_directory\panel_hunter_intermed_MS2_android.dta", replace


****************************************************************************************
***Here, we generate a panel at the hunter-ios-date level; the date is year-month
****************************************************************************************


**We take the panel_hunter_intermed_MS_ios.dta generated just above
use "$intermediary_directory\panel_hunter_intermed_MS_ios.dta", replace

**We generate a balanced panel at the Hunter level
drop Hunted_By
xtset hunter_id edate
tsfill, full
sort hunter_id edate


**We add back the Hunted_By variable
merge m:1 hunter_id using "$intermediary_directory\panel_hunter_intermed_MS2_ios.dta",  keep(3) nogen  keepusing(Hunted_By)

**We replace missing values with zeros
replace sum_product_hunted=0 if sum_product_hunted==.
replace sum_product_hunted_upv90=0 if sum_product_hunted_upv90==.
replace sum_launched_startup=0 if sum_launched_startup==.
replace sum_launched_startupf=0 if sum_launched_startupf==.

**We generate a dummy for whether a hunter hunted a given app in a given year-month
gen product_hunted_dummy=sum_product_hunted>0

**We generate a dummies for whether hunters hunted top apps, apps that became startups, and apps that became funded startups
gen dproduct_hunted_upv90=sum_product_hunted_upv90>0
gen dsum_launched_startup=sum_launched_startup>0
gen dsum_launched_startupf=sum_launched_startupf>0


**We generate the experience measure for hunters using pre-period information on the top apps they had hunted 
gen sum_product_hunted_upv90t=sum_product_hunted_upv90
replace sum_product_hunted_upv90t=0 if edate>=tm(2019m10)
replace  sum_product_hunted_upv90t=0 if edate<tm(2018m1)
by  hunter_id (edate), sort: gen cumulative_exp=sum(sum_product_hunted_upv90t)
by  hunter_id, sort: egen max_exp=max(cumulative_exp)

**We drop observations pre-2019
**We drop hunters who did not hunt any iOS app during the focal period
keep if edate>=tm(2019m11)
by hunter_id, sort: egen ss=sum(sum_product_hunted)
keep if ss>0
drop ss


**We generate the post-announcement (for iOS) period 
gen post=edate>tm(2020m11)


**We define the period: 12 months before, the month of, and 12 months after Apple's announcement
gen time_to_cut = .
gen counter=edate==tm(2020m11)
forvalues t=-12/12 {
	di "`t'"
	local negt = `t' * -1
	bysort hunter_id (edate): replace time_to_cut = `t' if counter[_n + `negt'] == 1
}
drop counter
gen time_to_cut2=time_to_cut+12

**We generate the experienced-hunter dummy
capture drop dmax_exp
gen dmax_exp=max_exp>0

save "$intermediary_directory\panel_hunter_final_MS_ios.dta", replace



****************************************************************************************
***Here, we generate a panel at the hunter-Android-date level; the date is year-month
****************************************************************************************

**We take the panel_hunter_intermed_MS_android.dta generated just above
use "$intermediary_directory\panel_hunter_intermed_MS_android.dta", replace


**We generate a balanced panel at the Hunter level
drop Hunted_By
xtset hunter_id edate
tsfill, full
sort hunter_id edate


**We add back the Hunted_By variable
merge m:1 hunter_id using "$intermediary_directory\panel_hunter_intermed_MS2_android.dta",  keep(3) nogen  keepusing(Hunted_By)

**We replace missing values with zeros
replace sum_product_hunted=0 if sum_product_hunted==.
replace sum_product_hunted_upv90=0 if sum_product_hunted_upv90==.
replace sum_product_hunted_rat75=0 if sum_product_hunted_rat75==.
replace sum_launched_startup=0 if sum_launched_startup==.
replace sum_launched_startupf=0 if sum_launched_startupf==.

**We generate a dummy for whether a hunter hunted a given app in a given year-month
gen product_hunted_dummy=sum_product_hunted>0

**We generate a dummies for whether hunters hunted top apps, apps that became startups, and apps that became funded startups
gen dproduct_hunted_upv90=sum_product_hunted_upv90>0
gen dsum_launched_startup=sum_launched_startup>0
gen dsum_launched_startupf=sum_launched_startupf>0


**We generate the experience measure for hunters using pre-period information on the top apps they had hunted 
gen sum_product_hunted_upv90t=sum_product_hunted_rat75>0
replace sum_product_hunted_upv90t=0 if edate>=tm(2019m10)
replace  sum_product_hunted_upv90t=0 if edate<tm(2018m1)
by  hunter_id (edate), sort: gen cumulative_exp=sum(sum_product_hunted_upv90t)
by  hunter_id, sort: egen max_exp=max(cumulative_exp)

**We drop observations pre-2019
**We drop hunters who did not hunt any Android app during the focal period
keep if edate>=tm(2019m11)
by hunter_id, sort: egen ss=sum(sum_product_hunted)
keep if ss>0
drop ss

**We generate the post-announcement (for Android) period 
gen post=edate>tm(2021m2)


**We define the period: 12 months before, the month of, and 12 months after Google's announcement
gen time_to_cut = .
gen counter=edate==tm(2021m2)
forvalues t=-12/12 {
	di "`t'"
	local negt = `t' * -1
	bysort hunter_id (edate): replace time_to_cut = `t' if counter[_n + `negt'] == 1
}
drop counter
gen time_to_cut2=time_to_cut+12

**We generate the experienced-hunter dummy
capture drop dmax_exp
gen dmax_exp=max_exp>0

save "$intermediary_directory\panel_hunter_final_MS_android.dta", replace



**************************************************************************************************************************
***We append the hunter datasets (one for hunters on iOS and the other for hunters on Android) we generated above
**************************************************************************************************************************

use "$intermediary_directory\panel_hunter_final_MS_android.dta", replace
append using "$intermediary_directory\panel_hunter_final_MS_ios.dta", gen(ios)

**We clean up/standardize the hunter names
clean_name Hunted_By, case(proper)
stnd_compname Hunted_By, gen(stn_name stn_dbaname stn_fkaname entitytype attn_name)
drop stn_dbaname stn_fkaname attn_name
rename stn_name Hunted_Byy
drop entitytype

**We generate a new numerical identifier for each hunter
egen hunter_id_new=group(Hunted_Byy)

**We generate a numerical identifier for the hunter-platform
egen hunter_platform=group(hunter_id_new ios)

**We keep the variables we need
keep  product_hunted_dummy dproduct_hunted_upv90 dsum_launched_startup dsum_launched_startupf dmax_exp time_to_cut2 edate ios hunter_platform  hunter_id_new post

**Keep the focal period
keep if time_to_cut2!=.


****We label the variables we use
label var hunter_id_new "Hunter id"
label var hunter_platform "Hunter-platform id"
label var edate "year-month"
label var ios "ios==1 if Platform is iOS; ios==0 if Platform is Android"
label var product_hunted_dummy "App is Hunted"
label var  dproduct_hunted_upv90 "Hunted App: Last Percentile for Upvotes"
label var  dsum_launched_startup "Hunted App: Turned into Startup"
label var  dsum_launched_startupf  "Hunted App: Turned into Funded Startup"
label var dmax_exp "1 if Hunter is Experienced, 0 Otherwise"
label var post "Post-announcements"
label var time_to_cut2 "Counter for the 12 Months Before, the Month Of, and 12 Months After Each Announcement"

********************************************************************************
***We generate the final file: This is a panel at the hunter-platform level
********************************************************************************
save "$final_directory\panel_hunter_final.dta", replace




