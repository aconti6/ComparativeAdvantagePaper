
*********************************************************************************************************************************
*								The Hidden Costs of Fairness in Platform Markets: The Dynamics of Lowering Developer Royalty Rates
*********************************************************************************************************************************
											*********************************************
											*			Thus version: September 2025	*
											*		     annamaria.conti@ie.edu         *
											*			   juan.santalo@ie.edu		    *
											*********************************************



*************************************************************************************
*****************Regressions: TABLE 5
**************************************************************************************

clear all
set maxvar 120000

**Here we set the globals
	global shared_folder "D:\Project_Hunt_Anna_Juan\Analysis\DO\Replication_Package"
    global final_directory "${shared_folder}\final_datasets_for_regressions_figures"

*We used Stata18
*Packages required for running this do file: ppmlhdfe, ftools
*We have two datasets: one for iOS and the other for Android
*Each dataset is setup as an app panel.
*In each panel, we observe the monthly cumulative number of app downlowads and ASO investments 12 months before, the month of, and 12 months after each announcement.
*The apps we consider are those released before January 2019

***************************************************
*******Table 5: Columns 1-2 - iOS
***************************************************

use "$final_directory\ios_ASO_analysis.dta", replace

*Column 1
ppmlhdfe cum_sum_downloads  c.post##c.cum_aso_b  c.post##c.cum_size_b c.post##c.cum_version_b, absorb(apptweakid edate) cluster(apptweakid)
estimates store a1
*Column 2
ppmlhdfe cum_sum_downloads c.post##c.cum_title_all_b  c.post##c.cum_description_b c.post##c.cum_screenshots_b c.post##c.cum_icon_b c.post##c.cum_videos_b    c.post##c.cum_size_b c.post##c.cum_version_b , absorb(apptweakid edate) cluster(apptweakid)
estimates store a2

esttab a1 a2, keep(cum_aso_b c.post#c.cum_aso_b cum_title_all_b c.post#c.cum_title_all_b cum_description_b c.post#c.cum_description_b cum_screenshots_b c.post#c.cum_screenshots_b cum_icon_b c.post#c.cum_icon_b cum_videos_b c.post#c.cum_videos_b cum_size_b c.post#c.cum_size_b  cum_version_b c.post#c.cum_version_b)  s(N, label("Observations")) replace booktabs title(App Store Optimization (ASO): iOS & Android) label nobaselevels interaction(" $\times$ ") style(tex)  noconstant star(* 0.10 ** 0.05 *** 0.01) se mtitles("Cum. Downloads: iOS" "Cum. Downloads: iOS")  compress, using Table5_1_2.tex


***************************************************
*******Table 5: Columns 3-4 - iOS
***************************************************

use "$final_directory\android_ASO_analysis.dta", replace

*Column 3
ppmlhdfe cum_sum_downloads c.post##c.cum_aso_b   c.post##c.cum_size_b   c.post##c.cum_version_b , absorb(apptweakid edate) cluster(apptweakid)
estimates store a3

*Column 4
ppmlhdfe cum_sum_downloads c.post##c.cum_title_all_b  c.post##c.cum_description_b c.post##c.cum_screenshots_b c.post##c.cum_icon_b   c.post##c.cum_videos_b    c.post##c.cum_size_b   c.post##c.cum_version_b, absorb(apptweakid edate) cluster(apptweakid)
estimates store a4

esttab a3 a4, keep(cum_aso_b c.post#c.cum_aso_b cum_title_all_b c.post#c.cum_title_all_b cum_description_b c.post#c.cum_description_b cum_screenshots_b c.post#c.cum_screenshots_b cum_icon_b c.post#c.cum_icon_b cum_videos_b c.post#c.cum_videos_b cum_size_b c.post#c.cum_size_b  cum_version_b c.post#c.cum_version_b)  s(N, label("Observations")) replace booktabs title(App Store Optimization (ASO): iOS & Android) label nobaselevels interaction(" $\times$ ") style(tex)  noconstant star(* 0.10 ** 0.05 *** 0.01) se mtitles("Cum. Downloads: Android" "Cum. Downloads: Android")  compress, using Table5_3_4.tex