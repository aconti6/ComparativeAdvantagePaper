
*********************************************************************************************************************************
*								The Hidden Costs of Fairness in Platform Markets: The Dynamics of Lowering Developer Royalty Rates
*********************************************************************************************************************************
											*********************************************
											*			Thus version: September 2025	*
											*		     annamaria.conti@ie.edu         *
											*			   juan.santalo@ie.edu		    *
											*********************************************



*************************************************************************************
*****************Regressions: TABLE 4
**************************************************************************************

clear all
set maxvar 120000

**Here we set the globals
	global shared_folder "D:\Project_Hunt_Anna_Juan\Analysis\DO\Replication_Package"
    global final_directory "${shared_folder}\final_datasets_for_regressions_figures"
    global figures "${shared_folder}\figures"

**Here, we recall the file:
use "$final_directory\cross_section_product_hunt_MS.dta", replace
*This file was generated from the intermediary do-file ProductHunt_BuildingCrossSectionFile_Table4



**This is a cross-section with one entry for each platform-app
*We used Stata18
*Packages required for running this do file: reghdfe, ftools


*****************************************************************************************************************************************************************************************************
*****************Table 4: The association between upvotes, ratings, and being externally hunted with receiving VC funds post-announcements
*****************************************************************************************************************************************************************************************************

*We keep the singletons to have the same number of observations as in the main text. However, removing singletons does not change the p-vlaues of the coeffiicents




*Column 1
reghdfe launched_startupf c.post##c.launched_up75, absorb( ios#health_fitness#edate ios#developer_tools#edate  ios#music#edate ios#nutrition#edate   ios#e_commerce#edate ios#games#edate ios#analytics#edate ios#saas#edate  ios#artificial_intelligence#edate ios#productivity#edate  ios#augmented_reality#edate  ios#kids#edate ios#education#edate  ios#dating#edate ios#lifestyle#edate ios#investing#edate  ios#messaging#edate ios#task_management#edate ios#sales#edate  ios#web3#edate  ios#user_experience#edate  ios#photography#edate ios#travel#edate ios#social_network#edate ios#api#edate ios#streaming_services#edate ios#news#edate ios#marketing#edate ios#open_source#edate  ) cluster(platform_launch_date) keepsingletons
estadd local YPTech "Yes"
estadd ysumm
estimate store a1


*Column 2
reghdfe launched_startupf c.post##c.launched_ratw75, absorb( ios#health_fitness#edate ios#developer_tools#edate  ios#music#edate ios#nutrition#edate   ios#e_commerce#edate ios#games#edate ios#analytics#edate ios#saas#edate  ios#artificial_intelligence#edate ios#productivity#edate  ios#augmented_reality#edate  ios#kids#edate ios#education#edate  ios#dating#edate ios#lifestyle#edate ios#investing#edate  ios#messaging#edate ios#task_management#edate ios#sales#edate  ios#web3#edate  ios#user_experience#edate  ios#photography#edate ios#travel#edate ios#social_network#edate ios#api#edate ios#streaming_services#edate ios#news#edate ios#marketing#edate  ios#open_source#edate ) cluster(platform_launch_date) keepsingletons

estadd local YPTech "Yes"
estadd ysumm
estimate store a2


*Column 3
reghdfe launched_startupf c.post##c.launched_eh  , absorb(ios#health_fitness#edate ios#developer_tools#edate  ios#music#edate ios#nutrition#edate   ios#e_commerce#edate ios#games#edate ios#analytics#edate ios#saas#edate  ios#artificial_intelligence#edate ios#productivity#edate  ios#augmented_reality#edate  ios#kids#edate ios#education#edate  ios#dating#edate ios#lifestyle#edate ios#investing#edate  ios#messaging#edate ios#task_management#edate ios#sales#edate  ios#web3#edate  ios#user_experience#edate  ios#photography#edate ios#travel#edate ios#social_network#edate ios#api#edate ios#streaming_services#edate ios#news#edate ios#marketing#edate   ios#open_source#edate  ) cluster(platform_launch_date) keepsingletons
estadd local YPTech "Yes"
estadd ysumm
estimate store a3

esttab a1 a2 a3, keep(launched_up75 launched_ratw75 launched_eh c.post#c.launched_up75 c.post#c.launched_ratw75 c.post#c.launched_eh )  s(YPTech ymean N r2 , label("Year-month x Platform x Tech FEs"  "Mean D.V." "Observations" "R2")) replace booktabs title(Changes in the Role of Observable Quality Measures for VC Funding) label nobaselevels interaction(" $\times$ ") style(tex)  noconstant star(* 0.10 ** 0.05 *** 0.01) se mtitles("App Release: Apps turning into VC-funded startups" "App Release: Apps turning into VC-funded startups"  "App Release: Apps turning into VC-funded startups")  compress, using Table4.tex

