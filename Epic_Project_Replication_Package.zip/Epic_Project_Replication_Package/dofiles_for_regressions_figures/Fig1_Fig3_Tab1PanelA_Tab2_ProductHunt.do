

*********************************************************************************************************************************
*								The Hidden Costs of Fairness in Platform Markets: The Dynamics of Lowering Developer Royalty Rates
*********************************************************************************************************************************
											*********************************************
											*			Thus version: September 2025	*
											*		     annamaria.conti@ie.edu         *
											*			   juan.santalo@ie.edu		    *
											*********************************************



*************************************************************************************
*****************Regressions & Figures: FIGURE 1, FIGURE 3, TABLE 1- PANEL A, TABLE 2
**************************************************************************************

clear all
set maxvar 120000

**Here we set the globals
	global shared_folder "D:\Project_Hunt_Anna_Juan\Analysis\DO\Replication_Package"
    global final_directory "${shared_folder}\final_datasets_for_regressions_figures"
    global figures "${shared_folder}\figures"

**Here, we recall the file:
use "$final_directory\panel_firm_platform_final_MS.dta", replace
*This file was generated from the intermediary do-file ProductHunt_BuildingFinalFile



**This is a panel at the developer-platform level
*The panel ID is panel_id 
*The date variable is edate: it is in year-month date format
*ALL the variables have been labeled
*We observe the 12 months before, the month of, and the 12 months after each given shock: Apple's or Google's announcements
*The variable time_to_shock identifies each of the 12 months before, the month of, and each of the 12 months after each announcement
*The variable treatment identifies solo developers

*We used Stata18
*Packages required for running this do file: grc1leg, jwdid, reghdfe, ftools, sutex
*For jwdid please refer to: https://friosavila.github.io/app_metrics/app_metrics11.html
*The authors downloaded jwdid on October, 2024
*jwdid replicates the Mundlak regression model proposed by Wooldridge (2021)


****************************************************************************************
**Determine the staggered treatment a' la Callaway & Sant'Anna
**Precisely, we identify the time period when a specific group first receives treatment
****************************************************************************************

sort panel_id edate
gen gvar=tm(2020m12) if ios==1 &  treatment==1
replace gvar=tm(2021m3) if ios==0 &  treatment==1
replace gvar=0 if treatment==0
format gva %tm

label var gva "date of first treatment for treated platform-developers"

********************************************************
**WE START FROM THE FIGURES AND FOLLOW WITH THE TABLES
********************************************************

************************************************************
*Figure 1: Number of app launches on iOS/Android over time
************************************************************

*Panel A
preserve 
collapse (sum)  sum_launched, by( time_to_shock treatment)
twoway connected sum_launched time_to_shock if time_to_shock<0 & treatment==1, ms(O) mcolor(red)  lcolor(red)  || ///
connected sum_launched  time_to_shock if time_to_shock>=0 & treatment==1, mcolor(red) lcolor(red) ms(O) || ///
connected   sum_launched time_to_shock if time_to_shock<0 & treatment==0, lcolor(blue) mcolor(blue) ms(Oh) || ///
connected  sum_launched  time_to_shock if time_to_shock>=0 & treatment==0, mcolor(blue) lcolor(blue) ms(Oh)  ///
title("A: N. Apps Launched on iOS/Android" , size(small)) xtitle("Months to/since (Apple's/Android's) royalty rate cut", size(small)) ytitle("N. apps", size(small))  xline(0 ,lp(dash)) saving(f1_A.gph, replace) legend(order(1 "Team Size=1" 3 "Team Size>1") size(small) pos(6) col(2)) xlabel(,labsize(small)) ylabel(,labsize(small))
graph export "$figures\f1_A.png", replace	
restore

*Panel B
preserve 
collapse (sum)  sum_launched_up25, by( time_to_shock treatment)
twoway connected sum_launched_up25 time_to_shock if time_to_shock<0 & treatment==1, ms(O) mcolor(red)  lcolor(red) || ///
connected sum_launched_up25  time_to_shock if time_to_shock>=0 & treatment==1, mcolor(red) lcolor(red) ms(O) || ///
connected   sum_launched_up25 time_to_shock if time_to_shock<0 & treatment==0, lcolor(blue) mcolor(blue) ms(Oh) || ///
connected  sum_launched_up25  time_to_shock if time_to_shock>=0 & treatment==0, mcolor(blue) lcolor(blue) ms(Oh) ///
title("B: N. Low-quality Apps - Low Qrt. Upvotes" , size(small)) xtitle("", size(small)) ytitle("", size(small))  xline(0 ,lp(dash)) saving(f1_B.gph, replace) legend(order(1 "Team Size=1" 3 "Team Size>1")  size(small) pos(6) col(2)) xlabel(,labsize(small)) ylabel(,labsize(small))
graph export "$figures\f1_B.png", replace	
restore

*Panel C
preserve 
collapse (sum)  sum_launched_rat25, by( time_to_shock treatment)
twoway connected sum_launched_rat25 time_to_shock if time_to_shock<0 & treatment==1, ms(O) mcolor(red)  lcolor(red) || ///
connected sum_launched_rat25  time_to_shock if time_to_shock>=0 & treatment==1, mcolor(red) lcolor(red) ms(O) || ///
connected   sum_launched_rat25 time_to_shock if time_to_shock<0 & treatment==0, lcolor(blue) mcolor(blue) ms(Oh) || ///
connected  sum_launched_rat25  time_to_shock if time_to_shock>=0 & treatment==0, mcolor(blue) lcolor(blue) ms(Oh) ///
title("C: N. Low-quality Apps - Low Qrt. Rating" , size(small)) xtitle("", size(small)) ytitle("", size(small))  xline(0 ,lp(dash)) saving(f1_C.gph, replace) legend(order(1 "Team Size=1" 3 "Team Size>1")  size(small) pos(6) col(2)) xlabel(,labsize(small)) ylabel(,labsize(small))
graph export "$figures\f1_C.png", replace	
restore

*Panel D
preserve 
collapse (sum)  sum_launched_ih, by( time_to_shock treatment)
twoway connected sum_launched_ih time_to_shock if time_to_shock<0 & treatment==1, ms(O) mcolor(red)  lcolor(red) || ///
connected sum_launched_ih  time_to_shock if time_to_shock>=0 & treatment==1, mcolor(red) lcolor(red) ms(O) || ///
connected   sum_launched_ih time_to_shock if time_to_shock<0 & treatment==0, lcolor(blue) mcolor(blue) ms(Oh) || ///
connected  sum_launched_ih  time_to_shock if time_to_shock>=0 & treatment==0, mcolor(blue) lcolor(blue) ms(Oh) ///
title("D: N. Low-quality Apps - Self-Hunted" , size(small)) xtitle("", size(small)) ytitle("", size(small))  xline(0 ,lp(dash)) saving(f1_D.gph, replace) legend(order(1 "Team Size=1" 3 "Team Size>1")  size(small) pos(6) col(2)) xlabel(,labsize(small)) ylabel(,labsize(small))
graph export "$figures\f1_D.png", replace	
restore

*Panel E
preserve 
collapse (sum)  sum_launched_up75, by( time_to_shock treatment)
twoway connected sum_launched_up75 time_to_shock if time_to_shock<0 & treatment==1, ms(O) mcolor(red)  lcolor(red) || ///
connected sum_launched_up75  time_to_shock if time_to_shock>=0 & treatment==1, mcolor(red) lcolor(red) ms(O) || ///
connected   sum_launched_up75 time_to_shock if time_to_shock<0 & treatment==0, lcolor(blue) mcolor(blue) ms(Oh) || ///
connected  sum_launched_up75  time_to_shock if time_to_shock>=0 & treatment==0, mcolor(blue) lcolor(blue) ms(Oh) ///
title("E: N. High-quality Apps - Up Qrt. Upvotes" , size(small)) xtitle("", size(small)) ytitle("", size(small))  xline(0 ,lp(dash)) saving(f1_E.gph, replace) legend(order(1 "Team Size=1" 3 "Team Size>1")  size(small) pos(6) col(2)) xlabel(,labsize(small)) ylabel(,labsize(small))
graph export "$figures\f1_E.png", replace	
restore

*Panel F
preserve 
collapse (sum)  sum_launched_rat75, by( time_to_shock treatment)
twoway connected sum_launched_rat75 time_to_shock if time_to_shock<0 & treatment==1, ms(O) mcolor(red)  lcolor(red) || ///
connected sum_launched_rat75  time_to_shock if time_to_shock>=0 & treatment==1, mcolor(red) lcolor(red) ms(O) || ///
connected   sum_launched_rat75 time_to_shock if time_to_shock<0 & treatment==0, lcolor(blue) mcolor(blue) ms(Oh) || ///
connected  sum_launched_rat75  time_to_shock if time_to_shock>=0 & treatment==0, mcolor(blue) lcolor(blue) ms(Oh) ///
title("F: N. High-quality Apps - Up Qrt. Rating" , size(small)) xtitle("", size(small)) ytitle("", size(small))  xline(0 ,lp(dash)) saving(f1_F.gph, replace) legend(order(1 "Team Size=1" 3 "Team Size>1")  size(small) pos(6) col(2)) xlabel(,labsize(small)) ylabel(,labsize(small))
graph export "$figuresf1_F.png", replace	
restore

*Panel G
preserve 
collapse (sum)  sum_launched_eh, by( time_to_shock treatment)
twoway connected sum_launched_eh time_to_shock if time_to_shock<0 & treatment==1, ms(O) mcolor(red)  lcolor(red) || ///
connected sum_launched_eh  time_to_shock if time_to_shock>=0 & treatment==1, mcolor(red) lcolor(red) ms(O) || ///
connected   sum_launched_eh time_to_shock if time_to_shock<0 & treatment==0, lcolor(blue) mcolor(blue) ms(Oh) || ///
connected  sum_launched_eh  time_to_shock if time_to_shock>=0 & treatment==0, mcolor(blue) lcolor(blue) ms(Oh) ///
title("G: N. High-quality Apps - Externally Certified" , size(small)) xtitle("", size(small)) ytitle("", size(small))  xline(0 ,lp(dash)) saving(f1_G.gph, replace) legend(order(1 "Team Size=1" 3 "Team Size>1")  size(small) pos(6) col(2)) xlabel(,labsize(small)) ylabel(,labsize(small))
graph export "$figures\f1_G.png", replace	
restore

**Here, we combine the graphs into Figure 1
grc1leg f1_A.gph f1_B.gph f1_C.gph f1_D.gph f1_E.gph f1_F.gph f1_G.gph, cols(3)  imargin(0 0 0 0 0 0 0) graphregion(margin(l=23 r=23)) span  graphregion(color(white)) holes (2 3)
graph export "$figures\Figure1.png", replace	


************************************************************
*Figure 3: App launches: Event studies
************************************************************

capture erase "$figures\fig3a.jpg", replace
jwdid d_sum_launched, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estat event
jwdid_plot, title("A: Two-Way Mundlak Regression: App Launch",  size(small))  xtitle("Months to/since (Apple's/Android's) royalty rate cut", size(small)) ytitle("App launch", size(small)) xlabel(,labsize(small)) ylabel(,labsize(small))  legend(order(1 "Before" 3 "After")) saving(fig3a.gph, replace)
        # delimit cr
graph export "$figures\fig3a.jpg", as(jpg) name("Graph") quality(100)


capture erase "$figures\fig3b.jpg""
jwdid d_sum_launched_up25, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estat event
jwdid_plot, title("B: Low Qrt. Upvotes",  size(small))  xtitle("", size(small)) ytitle("", size(small)) xlabel(,labsize(small)) ylabel(,labsize(small)) legend(order(1 "Before" 3 "After")) saving(fig3b.gph, replace)
        # delimit cr
graph export "$figures\fig3b", as(jpg) name("Graph") quality(100)

capture erase "$figures\fig3c.jpg"
jwdid d_sum_launched_rat25, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estat event
jwdid_plot, title("C: Low Qrt. Ratings",  size(small))  xtitle("", size(small)) ytitle("", size(small)) xlabel(,labsize(small)) ylabel(,labsize(small)) legend(order(1 "Before" 3 "After")) saving(fig3c.gph, replace)
        # delimit cr
graph export "$figures\fig3c.jpg", as(jpg) name("Graph") quality(100)


capture erase "$figures\fig3d"
jwdid d_sum_launched_ih, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estat event
jwdid_plot, title("D: Self-certified",  size(small))  xtitle("", size(small)) ytitle("", size(small)) xlabel(,labsize(small)) ylabel(,labsize(small)) legend(order(1 "Before" 3 "After")) saving(fig3d.gph, replace)
        # delimit cr
graph export "$figures\fig3d.jpg", as(jpg) name("Graph") quality(100)

**

capture erase "$figures\fig3e""
jwdid d_sum_launched_up75, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estat event
jwdid_plot, title("E: Up Qrt. Upvotes",  size(small))  xtitle("", size(small)) ytitle("", size(small)) xlabel(,labsize(small)) ylabel(,labsize(small)) legend(order(1 "Before" 3 "After")) saving(fig3e.gph, replace)
        # delimit cr
graph export "$figures\fig3e", as(jpg) name("Graph") quality(100)


capture erase "$figures\fig3f.jpg"
jwdid d_sum_launched_rat75, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estat event
jwdid_plot, title("F: Up Qrt. Ratings",  size(small))  xtitle("", size(small)) ytitle("", size(small)) xlabel(,labsize(small)) ylabel(,labsize(small)) legend(order(1 "Before" 3 "After")) saving(fig3f.gph, replace)
        # delimit cr
graph export "$figures\fig3f.jpg", as(jpg) name("Graph") quality(100)


capture erase "$figures\fig3g.jpg"
jwdid d_sum_launched_eh, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estat event
jwdid_plot, title("G: Externally certified",  size(small))  xtitle("", size(small)) ytitle("", size(small)) xlabel(,labsize(small)) ylabel(,labsize(small)) legend(order(1 "Before" 3 "After")) saving(fig3g.gph, replace)
        # delimit cr
graph export "$figures\fig3g.jpg", as(jpg) name("Graph") quality(100)

capture erase "$figures\fig3h.jpg"
jwdid d_sum_launched_startup, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estat event
jwdid_plot, title("H: Launch of an App That Turns into a Startup",  size(small))  xtitle("Months to/since (Apple's/Android's) royalty rate cut", size(small)) ytitle("", size(small)) xlabel(,labsize(small)) ylabel(,labsize(small))  legend(order(1 "Before" 3 "After")) saving(fig3h.gph, replace)
        # delimit cr
graph export "$figures\fig3h.jpg", as(jpg) name("Graph") quality(100)


capture erase "$figures\fig3i.jpg"
jwdid d_sum_launched_startupf, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estat event
jwdid_plot, title("I: Launch of an App That Turns into a Funded Startup",  size(small))  xtitle("", size(small)) ytitle("", size(small)) xlabel(,labsize(small)) ylabel(,labsize(small)) legend(order(1 "Before" 3 "After")) saving(fig3i.gph, replace)
        # delimit cr
graph export "$figures\fig3i", as(jpg) name("Graph") quality(100)


**Here, we combine the graphs into Figure 3
grc1leg fig3a.gph fig3b.gph fig3c.gph fig3d.gph fig3e.gph fig3f.gph fig3g.gph fig3h.gph fig3i.gph, cols(3)  imargin(0 0 0 0 0 0 0 0 0) graphregion(margin(l=23 r=23)) span  graphregion(color(white)) holes (2 3)
graph export "$figures\Figure3.png", replace	



********************************************************
**Tables
********************************************************

**********************************
*Table 1: Panel A
**********************************

**These are the descriptive stats at the devleoper-team level (lines 1 to 7)

preserve
bys panel_id: egen msum_launched_ios=sum(sum_launched) if ios==1
bys panel_id: egen msum_launched_first_ios=sum(sum_launched_first) if ios==1
bys panel_id: egen msum_launched_follow_ios=sum(sum_launched_follow) if ios==1

bys panel_id: egen msum_launched_an=sum(sum_launched) if ios==0
bys panel_id: egen msum_launched_first_an=sum(sum_launched_first) if ios==0
bys panel_id: egen msum_launched_follow_an=sum(sum_launched_follow) if ios==0

replace msum_launched_ios=0 if msum_launched_ios==.
replace msum_launched_first_ios=0 if msum_launched_first_ios==.
replace msum_launched_follow_ios=0 if msum_launched_follow_ios==.

replace msum_launched_an=0 if msum_launched_an==.
replace msum_launched_first_an=0 if msum_launched_first_an==.
replace msum_launched_follow_an=0 if msum_launched_follow_an==.


bys developer_team_id: egen mmsum_launched_android=max(msum_launched_an) 
bys developer_team_id: egen mmsum_launched_first_android=max(msum_launched_first_an) 
bys developer_team_id: egen mmsum_launched_follow_android=max(msum_launched_follow_an) 

bys developer_team_id: egen mmsum_launched_ios=max(msum_launched_ios) 
bys developer_team_id: egen mmsum_launched_first_ios=max(msum_launched_first_ios) 
bys developer_team_id: egen mmsum_launched_follow_ios=max(msum_launched_follow_ios) 

duplicates drop developer_team_id , force
sutex team_size mmsum_launched_ios mmsum_launched_first_ios mmsum_launched_follow_ios  mmsum_launched_android mmsum_launched_first_android mmsum_launched_follow_android, nobs minmax digits(3)

*team_size: line 1 of Panel A
*mmsum_launched_ios: line 2 of Panel A
*mmsum_launched_first_ios: line 3 of Panel A
*mmsum_launched_follow_ios: line 4 of Panel A
*mmsum_launched_android: line 5 of Panel A
*mmsum_launched_first_android: line 6 of Panel A
*mmsum_launched_follow_android: line 7 of Panel A
restore



**********************************
*Table 2: App Launches - Panel A
**********************************

*Column 1
jwdid d_sum_launched, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estadd ysumm, replace
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estat simple,  estore(a1)

*Column 2
jwdid d_sum_launched_up25, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a2)

*Column 3
jwdid d_sum_launched_rat25, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a3)

*Column 4
jwdid d_sum_launched_ih, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a4)

*Column 5
jwdid d_sum_launched_up75, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a5)


*Column 6
jwdid d_sum_launched_rat75, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a6)


*Column 7
jwdid d_sum_launched_eh, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a7)

*Column 8
jwdid d_sum_launched_startup, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a8)

*Column 9
jwdid d_sum_launched_startupf, ivar(panel_id) tvar(edate) gvar(gvar) never cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a9)


esttab a1 a2 a3 a4 a5 a6 a7 a8 a9, s(panel_id edate N ymean, label("Developer-platform FEs" "Year-month FEs" "Observations" "Mean D.V." )) replace booktabs title(App Launches) label nobaselevels style(tex)  noconstant star(* 0.10 ** 0.05 *** 0.01) se mtitles("Launch on iOS/Android"  "Low Qrt. Upvotes" "Low Qrt. Rating" "Self-Hunted" "High Qrt. Upvotes" "High Qrt. Rating" "Externally Certified" "Turning into a Venture"  "Turning into a Funded Venture")  compress, using Table2PanelA.tex

**********************************
*Table 2: App Launches - Panel B
**********************************

*Column 1
jwdid d_sum_launched, ivar(panel_id) tvar(edate) gvar(gvar)  cluster(panel_id)
estadd ysumm, replace
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estat simple,  estore(a1)

*Column 2
jwdid d_sum_launched_up25, ivar(panel_id) tvar(edate) gvar(gvar) cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a2)

*Column 3
jwdid d_sum_launched_rat25, ivar(panel_id) tvar(edate) gvar(gvar)  cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a3)

*Column 4
jwdid d_sum_launched_ih, ivar(panel_id) tvar(edate) gvar(gvar) cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a4)

*Column 5
jwdid d_sum_launched_up75, ivar(panel_id) tvar(edate) gvar(gvar)  cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a5)

*Column 6
jwdid d_sum_launched_rat75, ivar(panel_id) tvar(edate) gvar(gvar)  cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a6)


*Column 7
jwdid d_sum_launched_eh, ivar(panel_id) tvar(edate) gvar(gvar)  cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a7)

*Column 8
jwdid d_sum_launched_startup, ivar(panel_id) tvar(edate) gvar(gvar) cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a8)


*Column 9
jwdid d_sum_launched_startupf, ivar(panel_id) tvar(edate) gvar(gvar) cluster(panel_id)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a9)


esttab a1 a2 a3 a4 a5 a6 a7 a8 a9, s(panel_id edate N ymean, label("Developer-platform FEs" "Year-month FEs" "Observations" "Mean D.V." )) replace booktabs title(App Launches) label nobaselevels style(tex)  noconstant star(* 0.10 ** 0.05 *** 0.01) se mtitles("Launch on iOS/Android"  "Low Qrt. Upvotes" "Low Qrt. Rating" "Self-Hunted" "High Qrt. Upvotes" "High Qrt. Rating" "Externally Certified" "Turning into a Venture"  "Turning into a Funded Venture")  compress, using Table2PanelB.tex