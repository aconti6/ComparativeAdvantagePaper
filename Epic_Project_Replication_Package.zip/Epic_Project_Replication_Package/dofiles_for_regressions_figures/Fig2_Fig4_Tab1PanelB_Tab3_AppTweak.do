
*********************************************************************************************************************************
*								The Hidden Costs of Fairness in Platform Markets: The Dynamics of Lowering Developer Royalty Rates
*********************************************************************************************************************************
											*********************************************
											*			Thus version: September 2025	*
											*		     annamaria.conti@ie.edu         *
											*			   juan.santalo@ie.edu		    *
											*********************************************



*************************************************************************************
*****************Regressions & Figures: FIGURE 2, FIGURE 4, TABLE 1- PANEL B, TABLE 3
**************************************************************************************

clear all
set maxvar 120000

**Here we set the globals
	global shared_folder "D:\Project_Hunt_Anna_Juan\Analysis\DO\Replication_Package"
    global final_directory "${shared_folder}\final_datasets_for_regressions_figures"
    global figures "${shared_folder}\figures"

**Here, we recall the file:
use "$final_directory\AppTweak_developer_platform_panel.dta", replace
*This file was generated from the intermediary do-file AppTweak_BuildingFinalFile


**Data is from Apptweak for game apps
**This is a panel at the developer-platform level
*The panel ID is pi 
*The date variable is edate: it is in year-month date format
*ALL the variables have been labeled
*We observe the 12 months before, the month of, and the 12 months after each given shock: Apple's or Google's announcements
*The variable time_to_shock identifies each of the 12 months before, the month of, and each of the 12 months after each announcement
*The variable small_developer identifies small developers

*We used Stata18
*Packages required for running this do file: grc1leg, jwdid, reghdfe, ftools, sutex
*For jwdid please refer to: https://friosavila.github.io/app_metrics/app_metrics11.html
*The authors downloaded jwdid on October, 2024
*jwdid replicates the Mundlak regression model proposed by Wooldridge (2021)



***********************************************************************************************************
*Figures & Regressions
***********************************************************************************************************
*This is a panel at the developer-platform level
*Each developer platform is observed for 25 months: 12 months before, the month of, and 12 months after each announcement
use "$final_directory\AppTweak_developer_platform_panel.dta", replace


************************************************************************
***Figure 2:  Number of game app launches on iOS/Android over time
************************************************************************

*Panel A
preserve 
collapse (sum)  sum_launched, by( time_to_shock small_developer)
twoway connected sum_launched time_to_shock if time_to_shock<0 & small_developer==1, ms(O) mcolor(red)  lcolor(red)  || ///
connected sum_launched  time_to_shock if time_to_shock>=0 & small_developer==1, mcolor(red) lcolor(red) ms(O) || ///
connected   sum_launched time_to_shock if time_to_shock<0 & small_developer==0, lcolor(blue) mcolor(blue) ms(Oh) || ///
connected  sum_launched  time_to_shock if time_to_shock>=0 & small_developer==0, mcolor(blue) lcolor(blue) ms(Oh)  ///
title("A: N. Game Apps Launched on iOS/Android" , size(small)) xtitle("Months to/since (Apple's/Android's) royalty rate cut", size(small)) ytitle("N. apps", size(small))  xline(0 ,lp(dash)) saving(f2_A.gph, replace) legend(order(1 "Individual Dev.=1" 3 "Inc. Business>1") size(small) pos(6) col(2)) xlabel(,labsize(small)) ylabel(,labsize(small))
graph export "$figures\f2_A.png", replace	
restore

*Panel B
preserve 
collapse (sum)  sum_launched_zero_downloads, by( time_to_shock small_developer)
twoway connected sum_launched_zero_downloads time_to_shock if time_to_shock<0 & small_developer==1, ms(O) mcolor(red)  lcolor(red) || ///
connected sum_launched_zero_downloads  time_to_shock if time_to_shock>=0 & small_developer==1, mcolor(red) lcolor(red) ms(O) || ///
connected   sum_launched_zero_downloads time_to_shock if time_to_shock<0 & small_developer==0, lcolor(blue) mcolor(blue) ms(Oh) || ///
connected  sum_launched_zero_downloads  time_to_shock if time_to_shock>=0 & small_developer==0, mcolor(blue) lcolor(blue) ms(Oh) ///
title("B: N. Low-quality Apps - Zero Downloads" , size(small)) xtitle("", size(small)) ytitle("", size(small))  xline(0 ,lp(dash)) saving(f2_B.gph, replace) legend(order(1 "Individual Dev.=1" 3 "Inc. Business>1")  size(small) pos(6) col(2)) xlabel(,labsize(small)) ylabel(,labsize(small))
graph export "$figures\f2_B.png", replace	
restore

*Panel C
preserve 
collapse (sum)  sum_launched_high_75_download, by( time_to_shock small_developer)
twoway connected sum_launched_high_75_download time_to_shock if time_to_shock<0 & small_developer==1, ms(O) mcolor(red)  lcolor(red) || ///
connected sum_launched_high_75_download  time_to_shock if time_to_shock>=0 & small_developer==1, mcolor(red) lcolor(red) ms(O) || ///
connected   sum_launched_high_75_download time_to_shock if time_to_shock<0 & small_developer==0, lcolor(blue) mcolor(blue) ms(Oh) || ///
connected  sum_launched_high_75_download  time_to_shock if time_to_shock>=0 & small_developer==0, mcolor(blue) lcolor(blue) ms(Oh) ///
title("C: N. High-quality Apps - Up Qrt. Downloads" , size(small)) xtitle("", size(small)) ytitle("", size(small))  xline(0 ,lp(dash)) saving(f2_C.gph, replace) legend(order(1 "Individual Dev.=1" 3 "Inc. Business>1")  size(small) pos(6) col(2)) xlabel(,labsize(small)) ylabel(,labsize(small))
graph export "$figures\f2_C.png", replace	
restore

**Here, we combine the graphs into Figure 2
grc1leg f2_A.gph f2_B.gph f2_C.gph, cols(1)  imargin(0 0 0 ) graphregion(margin(l=20 r=20)) span  graphregion(color(white)) 
graph export "$figures\Figure2.png", replace	

***************************************************************************************************************
*Figure 4: Launches of game apps: Event studies - Distinguishing by downloads and between individual developers and incorporated businesses
***************************************************************************************************************

*Panel A
jwdid dsum_launched, ivar(pi) tvar(edate) gvar(gvar) never cluster(pi)
estat event
jwdid_plot, title("A: Two-Way Mundlak Regression: Game App Launch",  size(small))  xtitle("Months to/since (Apple's/Android's) royalty rate cut", size(small)) ytitle("App launch", size(small)) xlabel(,labsize(small)) ylabel(,labsize(small))  legend(order(1 "Before" 3 "After")) saving(fig4a.gph, replace)
        # delimit cr
graph export "$figures\fig4a.jpg", as(jpg) name("Graph") quality(100)

*Panel B
jwdid dsum_launched_zero_downloads, ivar(pi) tvar(edate) gvar(gvar) never cluster(pi)
estat event
jwdid_plot, title("B: Zero Downloads",  size(small))  xtitle("", size(small)) ytitle("", size(small)) xlabel(,labsize(small)) ylabel(,labsize(small))  legend(order(1 "Before" 3 "After")) saving(fig4b.gph, replace)
        # delimit cr
graph export "$figures\fig4b.jpg", as(jpg) name("Graph") quality(100)

*Panel C
jwdid dsum_launched_high_75_download, ivar(pi) tvar(edate) gvar(gvar) never cluster(pi)
estat event
jwdid_plot, title("C: Up Qrt. Downloads",  size(small))  xtitle("", size(small)) ytitle("", size(small)) xlabel(,labsize(small)) ylabel(,labsize(small))  legend(order(1 "Before" 3 "After")) saving(fig4c.gph, replace)
        # delimit cr
graph export "$figures\fig4c.jpg", as(jpg) name("Graph") quality(100)


**Here, we combine the graphs into Figure 4
grc1leg fig4a.gph fig4b.gph fig4c.gph , cols(1)  imargin(0 0 0 ) graphregion(margin(l=23 r=23)) span  graphregion(color(white)) 
graph export "$figures\Figure4.png", replace	


******************************************************************
*Table 1: Summary statistics (At the developer level) - Panel B
*****************************************************************
**Descriptive statistic on small developer: Line 1 of Panel B
preserve
duplicates drop gd, force
sum small_developer, detail
restore

**Descriptive statistics on launches on iOS and Android at the developer level: Lines 2 and 3 of Panel B

preserve

bys pi (edate): egen s_sum_launched_ios=sum(sum_launched) if ios==1
bys pi (edate): egen s_sum_launched_an=sum(sum_launched) if ios==0

replace s_sum_launched_ios=0 if s_sum_launched_ios==.
replace s_sum_launched_an=0 if s_sum_launched_an==.

bys gd: egen max_sum_launched_ios=max(s_sum_launched_ios)
bys gd: egen max_sum_launched_an=max(s_sum_launched_an)

duplicates drop gd, force

sutex max_sum_launched_ios max_sum_launched_an, nobs minmax digits(3)

restore



**********************************
*Table 3: Game Apps - Panel A
**********************************

*Column 1
jwdid dsum_launched, ivar(pi) tvar(edate) gvar(gvar) never cluster(pi)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a1)

*Column 2
jwdid dsum_launched_zero_downloads, ivar(pi) tvar(edate) gvar(gvar) never cluster(pi)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a2)

*Column 3
jwdid dsum_launched_high_75_download, ivar(pi) tvar(edate) gvar(gvar) never cluster(pi)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a3)

esttab a1 a2 a3, s(panel_id edate N ymean, label("Developer-platform FEs" "Year-month FEs" "Observations" "Mean D.V." )) replace booktabs title(Game apps on iOS/Android) label nobaselevels style(tex)  noconstant star(* 0.10 ** 0.05 *** 0.01) se mtitles("Game app launch" "Zero Downloads" "High Qrt. Downloads")  compress, using Table3PanelA.tex


**********************************
*Table 3 Game Apps - Panel B
**********************************

*Column 1
jwdid dsum_launched, ivar(pi) tvar(edate) gvar(gvar)  cluster(pi)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a1)

*Column 2
jwdid dsum_launched_zero_downloads, ivar(pi) tvar(edate) gvar(gvar) cluster(pi)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a2)

*Column 3
jwdid dsum_launched_high_75_download, ivar(pi) tvar(edate) gvar(gvar)  cluster(pi)
estadd local panel_id "Yes", replace
estadd local edate "Yes", replace
estadd ysumm, replace
estat simple,  estore(a3)

esttab a1 a2 a3, s(panel_id edate N ymean, label("Developer-platform FEs" "Year-month FEs" "Observations" "Mean D.V." )) replace booktabs title(Game apps on iOS/Android) label nobaselevels style(tex)  noconstant star(* 0.10 ** 0.05 *** 0.01) se mtitles("Game app launch" "Zero Downloads" "High Qrt. Downloads")  compress, using Table3PanelB.tex


